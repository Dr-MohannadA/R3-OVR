# OVR System - ASP.NET Core Setup Instructions

## Quick Start Guide

### Prerequisites
1. **.NET 8.0 SDK** - Download from https://dotnet.microsoft.com/download/dotnet/8.0
2. **SQL Server** - SQL Server Express, Developer, or Standard edition
3. **Visual Studio 2022** or **VS Code** (optional but recommended)

### Step 1: Database Setup

**Option A: Using SQL Server Management Studio (SSMS)**
1. Open SSMS and connect to your SQL Server instance
2. Execute scripts in this order:
   - `database/01_CreateDatabase.sql`
   - `database/02_InsertSeedData.sql`
   - `database/03_ConfigureSQLServer.sql`
   - `database/04_ProductionSetup.sql` (for production only)

**Option B: Using Command Line**
```bash
sqlcmd -S localhost -E -i database/01_CreateDatabase.sql
sqlcmd -S localhost -E -i database/02_InsertSeedData.sql
sqlcmd -S localhost -E -i database/03_ConfigureSQLServer.sql
```

### Step 2: Update Connection String

Edit `server-dotnet/appsettings.json`:
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=OVRSystem;Trusted_Connection=true;"
  }
}
```

**Common Connection Strings:**
- **Local SQL Server Express:** `Server=.\\SQLEXPRESS;Database=OVRSystem;Trusted_Connection=true;`
- **Full SQL Server with Auth:** `Server=localhost;Database=OVRSystem;User Id=sa;Password=YourPassword;`

### Step 3: Run the Application

```bash
# Navigate to the API project
cd server-dotnet

# Restore NuGet packages
dotnet restore

# Run the application
dotnet run
```

The API will be available at:
- **HTTP:** http://localhost:5000
- **HTTPS:** https://localhost:5001
- **Swagger UI:** https://localhost:5001/swagger

### Step 4: Default Login

- **Email:** admin@r3hc.sa
- **Password:** Aa123@Aa

## Production Deployment

### Using IIS
1. Build for production: `dotnet publish -c Release -o ./publish`
2. Copy published files to IIS wwwroot
3. Configure IIS application pool for .NET Core
4. Update `appsettings.Production.json` with production connection string

### Using Docker
1. Build image: `docker build -t ovr-system .`
2. Run with Docker Compose: `docker-compose up -d`
3. Access application at http://localhost:5000

### Using Azure App Service
1. Create Azure App Service with .NET 8 runtime
2. Create Azure SQL Database
3. Deploy using Visual Studio or Azure DevOps
4. Configure connection strings in Azure portal

## Project Structure

```
EngTariq/
├── server-dotnet/              # ASP.NET Core API
│   ├── Controllers/            # API Controllers
│   ├── Data/                   # Entity Framework DbContext
│   ├── DTOs/                   # Data Transfer Objects
│   ├── Models/                 # Entity Models
│   ├── Services/               # Business Logic
│   ├── Mappings/               # AutoMapper Profiles
│   └── Program.cs              # Application Entry Point
├── database/                   # SQL Server Scripts
│   ├── 01_CreateDatabase.sql   # Database Schema
│   ├── 02_InsertSeedData.sql   # Initial Data
│   ├── 03_ConfigureSQLServer.sql # Performance Config
│   └── 04_ProductionSetup.sql  # Production Config
├── OVRSystem.sln              # Visual Studio Solution
└── README-DotNet.md           # Detailed Documentation
```

## API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/register` - User registration
- `GET /api/auth/user` - Get current user

### Incidents
- `GET /api/incidents` - Get incidents (filtered by user)
- `POST /api/incidents` - Create incident
- `PATCH /api/incidents/{id}` - Update incident
- `GET /api/incidents/{id}` - Get specific incident

### Comments
- `GET /api/incidents/{id}/comments` - Get comments
- `POST /api/incidents/{id}/comments` - Add comment

### Admin Endpoints
- `GET /api/users` - Get all users (admin only)
- `GET /api/users/registrations/pending` - Pending registrations
- `POST /api/users/registrations/{id}/review` - Approve/reject registration

## Troubleshooting

### Common Issues

1. **Connection String Error**
   - Verify SQL Server is running
   - Check server name and authentication method
   - Test connection with SSMS

2. **Database Not Created**
   - Run database scripts manually in SSMS
   - Check SQL Server permissions
   - Verify database name matches connection string

3. **JWT Token Issues**
   - Ensure JWT key in appsettings.json is at least 256 bits
   - Check token expiration settings
   - Verify issuer and audience match

4. **Entity Framework Errors**
   - Run `dotnet ef database update`
   - Delete Migrations folder and recreate
   - Check model configurations in DbContext

### Getting Help

1. Check logs in console output
2. Enable detailed logging in appsettings.json
3. Use SQL Server Profiler to debug database issues
4. Test API endpoints using Swagger UI

## Security Notes

- Change default admin password immediately
- Use strong JWT secret keys in production
- Enable HTTPS in production
- Configure CORS appropriately
- Use dedicated database user with minimal permissions
- Enable audit logging for compliance

This ASP.NET Core implementation provides enterprise-grade security, performance, and scalability for the healthcare incident reporting system.